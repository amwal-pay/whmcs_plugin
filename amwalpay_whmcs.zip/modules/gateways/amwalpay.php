<?php

/**
 * WHMCS AmwalPay Payment Gateway Module
 *
 * If your module or third party API does not support a given function, you
 * should not define that function within your module. Only the _config
 * function is required.
 *
 * For more information, please refer to the online documentation.
 *
 * @see https://developers.whmcs.com/payment-gateways/
 *
 * @copyright Copyright (c) WHMCS Limited 2017
 * @license http://www.whmcs.com/license/ WHMCS Eula
 */
//use WHMCS\Database\Capsule;



if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}
require_once __DIR__ . '../../../init.php';
require_once 'amwalpay/library/AmwalPay.php';

//-----------------------------------------------------------------------------------------------------------------------------------------
/**
 * Define module related meta data.
 *
 * Values returned here are used to determine module related capabilities and
 * settings.
 *
 * @see https://developers.whmcs.com/payment-gateways/meta-data-params/
 *
 * @return array
 */
function amwalpay_MetaData()
{
    return array(
        'DisplayName' => 'Amwal Pay',
        'APIVersion' => '1.0.0',
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}

//-----------------------------------------------------------------------------------------------------------------------------------------
/**
 * Define gateway configuration options.
 *
 * The fields you define here determine the configuration options that are
 * presented to administrator users when activating and configuring your
 * payment gateway module for use.
 *
 * Supported field types include:
 * * text
 * * password
 * * yesno
 * * dropdown
 * * radio
 * * textarea
 *
 * Examples of each field type and their possible configuration parameters are
 * provided in the sample function below.
 *
 * @return array
 */
use WHMCS\Config\Setting;

function amwalpay_config()
{
    $url = Setting::getValue('SystemURL');

    return array(
        // the friendly display name for a payment gateway should be
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'Amwal Pay',
        ),
        // the friendly display name for a payment gateway should be
        'enabled' => array(
            'FriendlyName' => 'Enable/Disable',
            'Type' => 'yesno',
            'Description' => 'Enable Amwal Pay Payment Provider',
        ),
        'live' => array(
            'FriendlyName' => 'Environment',
            'Type' => 'dropdown',
            'Options' => 'Production,SIT,UAT',
            'Default' => 'UAT',
        ),
        // a text field type allows for single line text input
        'merchant_id' => array(
            'FriendlyName' => 'Merchant id',
            'Type' => 'text',
            'Default' => '',
        ),
        'terminal_id' => array(
            'FriendlyName' => 'Terminal id',
            'Type' => 'text',
            'Default' => '',
        ),
        'secret_key' => array(
            'FriendlyName' => 'Secret key',
            'Type' => 'text',
            'Default' => '',
        ),
        'debug' => array(
            'FriendlyName' => 'Debug Log',
            'Type' => 'yesno',
            'Description' => 'Log file will be saved in ' . ROOTDIR . '/modules/gateways/amwalpay/',
        ),
    );
}

//-----------------------------------------------------------------------------------------------------------------------------------------
/**
 * Payment link.
 *
 * Required by third party payment gateway modules only.
 *
 * Defines the HTML output displayed on an invoice. Typically consists of an
 * HTML form that will take the user to the payment gateway endpoint.
 *
 * @param array $params Payment Gateway Module Parameters
 *
 * @see https://developers.whmcs.com/payment-gateways/third-party-gateway/
 *
 * @return string
 */
function amwalpay_link($params)
{
    try {
        if ($params['debug'] == "on") {
            $debug = '1';
        }
        $base_url=Setting::getValue('SystemURL');
        $callback_url = $base_url . '/modules/gateways/amwalpay/callback.php';
        $file = ROOTDIR . '/modules/gateways/amwalpay/amwalpay.log';
        $live = $params['live'];
        $merchant_id = $params['merchant_id'];
        $terminal_id = $params['terminal_id'];
        $secret_key = $params['secret_key'];
        $refNumber = $params['invoiceid'] . '_' . date('ymds');
        $amount = isset($params['basecurrencyamount']) ? $params['basecurrencyamount'] : $params['amount'];


        $locale = Setting::getValue('Language'); // Get the current language locale

        $datetime = date('YmdHis');

        // // if $locale content en make $locale = "en"
        if (strpos($locale, 'english') !== false) {
            $locale = "en";
        } else {
            $locale = "ar";
        }

        // // Generate secure hash
        $secret_key = AmwalPay::generateString(
            $amount,
            512,
            $merchant_id,
            $refNumber,
            $terminal_id,
            $secret_key,
            $datetime
        );

        $data = (object) [
            'AmountTrxn' => "$amount",
            'MerchantReference' => "$refNumber",
            'MID' => $merchant_id,
            'TID' => $terminal_id,
            'CurrencyId' => 512,
            'LanguageId' => $locale,
            'SecureHash' => $secret_key,
            'TrxDateTime' => $datetime,
            'PaymentViewType' => 1,
            'RequestSource' => 'WHMCS',
            'SessionToken' => '',
        ];
        AmwalPay::addLogs($debug, $file, 'Payment Request: ', print_r($data, 1));
        $jsonData = json_encode($data);
        $smartbox_js = smartBoxUrl($live);
       

        $html = '<script type="text/javascript" src="' . $smartbox_js . '"></script>';

        $html .= '
                <script>
                var jsondata = ' . $jsonData . ';
                    setTimeout(function () {
                    if (window.location.href.includes("viewinvoice.php")) {
                // Parse JSON string to JavaScript object
                // var data = JSON.parse(jsondata);
                
                callSmartBox(jsondata);
            }
            }, 2000);

            function callSmartBox(data) {
                if (data["MID"] === "" || data["TID"] === "") {
                    document.getElementById("Error").style.display = "block";
                    return;
                }
                    var base_url = "'.$base_url.'";
                    var callback_url = "'.$callback_url.'";
                console.log(data);
                SmartBox.Checkout.configure = {
                    ...data,

                    completeCallback: function (data) {

                        var dateResponse = data.data.data;
                        window.location = callback_url + "?amount=" + dateResponse.amount + "&currencyId=" + dateResponse.currencyId + "&customerId=" + dateResponse.customerId + "&customerTokenId=" + dateResponse.customerTokenId + "&merchantReference=" + dateResponse.merchantReference + "&responseCode=" + data.data.responseCode + "&transactionId=" + dateResponse.transactionId + "&transactionTime=" + dateResponse.transactionTime + "&secureHashValue=" + dateResponse.secureHashValue;
                    },
                    errorCallback: function (data) {

                    },
                    cancelCallback: function () {
                        window.location = base_url
                    },
                };

                SmartBox.Checkout.showSmartBox()
            }

            </script>
        ';
        return $html;
    } catch (Exception $ex) {
        echo '<div align="center">AmwalPay Gateway Error : <br>' . $ex->getMessage();
        die;
    }

}

function smartBoxUrl($live)
{
    if ($live == "Production") {
        $liveurl = "https://checkout.amwalpg.com/js/SmartBox.js?v=1.1";
    } else if ($live == "UAT") {
        $liveurl = "https://test.amwalpg.com:7443/js/SmartBox.js?v=1.1";
    } else if ($live == "SIT") {
        $liveurl =
            "https://test.amwalpg.com:19443/js/SmartBox.js?v=1.1";

    }
    return $liveurl;
}
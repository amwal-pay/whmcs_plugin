<?php

// Require libraries needed for gateway module functions.
require_once __DIR__ . '/../../../init.php';
require_once 'library/AmwalPay.php';
use Illuminate\Database\Capsule\Manager as Capsule;
use WHMCS\Config\Setting;

$whmcs->load_function('gateway');
$whmcs->load_function('invoice');
$url = Setting::getValue('SystemURL');
// Fetch gateway configuration parameters.
$params = getGatewayVariables('amwalpay');
if ($params['debug'] == "on") {
    $debug = '1';
}

$message = null;
$paymentFee = null;
$invoiceId = null;
$transactionId = null;
$transactionStatus = 'Unpaid';
$paymentAmount = null;
$file = ROOTDIR . '/modules/gateways/amwalpay/amwalpay.log';
// Die if module is not active.
if (!$params['type']) {
    die("Payment Module is not activate");
}

if (AmwalPay::sanitizeVar('REQUEST_METHOD', 'SERVER') === 'GET') {
    list($invoiceId, ) = explode('_', AmwalPay::sanitizeVar('merchantReference'));
    $transactionId = AmwalPay::sanitizeVar('transactionId');
    $_POST['x_invoice_id'] = $invoiceId;
    $_POST['x_trans_id'] = $transactionId;

    $isPaymentApproved = false;

    $integrityParameters = [
        "amount" => AmwalPay::sanitizeVar('amount'),
        "currencyId" => AmwalPay::sanitizeVar('currencyId'),
        "customerId" => AmwalPay::sanitizeVar('customerId'),
        "customerTokenId" => AmwalPay::sanitizeVar('customerTokenId'),
        "merchantId" => $params['merchant_id'],
        "merchantReference" => AmwalPay::sanitizeVar('merchantReference'),
        "responseCode" => AmwalPay::sanitizeVar('responseCode'),
        "terminalId" => $params['terminal_id'],
        "transactionId" => AmwalPay::sanitizeVar('transactionId'),
        "transactionTime" => AmwalPay::sanitizeVar('transactionTime')
    ];

    AmwalPay::addLogs($debug, $file, 'Callback Response: ', print_r($integrityParameters, 1));
    $secureHashValue = AmwalPay::generateStringForFilter($integrityParameters, $params['secret_key']);
    $integrityParameters['secureHashValue'] = $secureHashValue;
    $integrityParameters['secureHashValueOld'] = AmwalPay::sanitizeVar('secureHashValue');

    if ((AmwalPay::sanitizeVar('responseCode') === '00' && $secureHashValue == AmwalPay::sanitizeVar('secureHashValue'))) {
        $isPaymentApproved = true;
    }

    if ($isPaymentApproved) {
        $transactionStatus = 'Paid';
        $paymentAmount = AmwalPay::sanitizeVar('amount');
        addInvoicePayment(
            $invoiceId,
            $transactionId,
            $paymentAmount,
            $paymentFee,
            $params['name']
        );
        $note = 'AmwalPay : Payment Approved';
        $msg = 'In callback action, for order #' . $invoiceId . ' ' . $note;
        AmwalPay::addLogs($debug, $file, $msg);
        $link = $url . '/viewinvoice.php?id=' . $invoiceId . '&paymentsuccess=true';
        header('Location:' . $link, true);

    } else {

        $_POST['x_error'] = $message = 'Payment return: Invoice is not Paid';
        $note = 'AmwalPay : Payment is not completed';
        $msg = 'In callback action, for order #' . $invoiceId . ' ' . $note;
        AmwalPay::addLogs($debug, $file, $msg);
        $link = $url . '/viewinvoice.php?id=' . $invoiceId . '&paymentfailed=true';
        header('Location:' . $link, true);

    }
    logTransaction($params['name'], $_POST, $transactionStatus);
} elseif (AmwalPay::sanitizeVar('REQUEST_METHOD', 'SERVER') === 'POST') {

    $post_data = file_get_contents('php://input');
    $json_data = json_decode($post_data, true);
   
    AmwalPay::addLogs($debug, $file, 'In Cloud Notification Response: ', print_r($json_data, 1));
    if (empty($json_data)) {
        AmwalPay::addLogs($debug, $file, 'Ops. you are accessing wrong order.');
        die('Ops. you are accessing wrong order.');
    }

    if ($json_data['MerchantId'] != $params['merchant_id'] || $json_data['TerminalId'] != $params['terminal_id']) {
        AmwalPay::addLogs($debug, $file, 'Ops. your configuration is mismatched.');
        die('Ops. your configuration is mismatched.');
    }

    $integrityParameters = [
        "Amount" => $json_data['Amount'],
        "AuthorizationDateTime" => $json_data['AuthorizationDateTime'],
        "CurrencyId" => $json_data['CurrencyId'],
        "DateTimeLocalTrxn" => $json_data['DateTimeLocalTrxn'],
        "MerchantId" => $params['merchant_id'],
        "MerchantReference" => $json_data['MerchantReference'],
        "Message" => $json_data['Message'],
        "PaidThrough" => $json_data['PaidThrough'],
        "ResponseCode" => $json_data['ResponseCode'],
        "SystemReference" => $json_data['SystemReference'],
        "TerminalId" => $params['terminal_id'],
        "TxnType" => $json_data['TxnType']
    ];

    $secureHashValue = AmwalPay::generateStringForFilter($integrityParameters, $params['secret_key']);
    $integrityParameters['secureHashValue'] = $secureHashValue;
    $integrityParameters['secureHashValueOld'] = $json_data['SecureHash'];

    AmwalPay::addLogs($debug, $file, 'Calculated Hash: ', print_r($integrityParameters, 1));

    list($invoiceId, ) = explode('_', $json_data['MerchantReference']);
    if (
        $json_data['ResponseCode'] === '00' && $secureHashValue == $json_data['SecureHash']
    ) {
        Capsule::table('tblinvoices')->where('id', $invoiceId)->update(['status' => 'Paid']);
        $note = 'AmwalPay : Payment Approved';
        $msg = $msg . ' ' . $note;
        AmwalPay::addLogs($debug, $file, $msg);
    } else {
        Capsule::table('tblinvoices')->where('id', $invoiceId)->update(['status' => 'Unpaid']);
        $note = 'AmwalPay : Payment is not completed ';
        $msg = $msg . ' ' . $note;
        AmwalPay::addLogs($debug, $file, $msg);
    }
    die("Order with invoice #$invoiceId updated");
} else {
    die("Ops, you are accessing wrong data");
}

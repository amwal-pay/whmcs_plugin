<?php

// Require libraries needed for gateway module functions.
require_once __DIR__ . '/../../../init.php';
require_once 'library/AmwalPay.php';
use Illuminate\Database\Capsule\Manager as Capsule;
use WHMCS\Config\Setting;

$whmcs->load_function('gateway');
$whmcs->load_function('invoice');
$url = Setting::getValue('SystemURL');
// Fetch gateway configuration parameters.
$params = getGatewayVariables('amwalpay');
if ($params['debug'] == "on") {
    $debug = '1';
}
$file = ROOTDIR . '/modules/gateways/amwalpay/amwalpay.log';
// Die if module is not active.
if (!$params['type']) {
    die("Payment Module is not activate");
}
$message = null;
$paymentFee = null;
$invoiceId = null;
$transactionId = null;
$transactionStatus = 'Unpaid';
$paymentAmount = null;
$invoiceId = substr(AmwalPay::sanitizeVar('merchantReference'), 0, -9);
$transactionId = AmwalPay::sanitizeVar('transactionId');
$_POST['x_invoice_id'] = $invoiceId;
$_POST['x_trans_id'] = $transactionId;

$isPaymentApproved = false;

$integrityParameters = [
    "amount" => AmwalPay::sanitizeVar('amount'),
    "currencyId" => AmwalPay::sanitizeVar('currencyId'),
    "customerId" => AmwalPay::sanitizeVar('customerId'),
    "customerTokenId" => AmwalPay::sanitizeVar('customerTokenId'),
    "merchantId" => $params['merchant_id'],
    "merchantReference" => AmwalPay::sanitizeVar('merchantReference'),
    "responseCode" => AmwalPay::sanitizeVar('responseCode'),
    "terminalId" => $params['terminal_id'],
    "transactionId" => AmwalPay::sanitizeVar('transactionId'),
    "transactionTime" => AmwalPay::sanitizeVar('transactionTime')
];
 
AmwalPay::addLogs($debug, $file, 'Callback Response: ', print_r($integrityParameters, 1));
$secureHashValue = AmwalPay::generateStringForFilter($integrityParameters, $params['secret_key']);
$integrityParameters['secureHashValue'] = $secureHashValue;
$integrityParameters['secureHashValueOld'] = AmwalPay::sanitizeVar('secureHashValue');

if ((AmwalPay::sanitizeVar('responseCode') === '00' || $secureHashValue == AmwalPay::sanitizeVar('secureHashValue'))) {
    $isPaymentApproved = true;
}

if ($isPaymentApproved) {
    $transactionStatus = 'Paid';
    $paymentAmount = AmwalPay::sanitizeVar('amount');
    addInvoicePayment(
        $invoiceId,
        $transactionId,
        $paymentAmount,
        $paymentFee,
        $params['name']
    );
    $note = 'AmwalPay : Payment Approved';
    $msg = 'In callback action, for order #'.$invoiceId.' '.$note;
    amwalpay::addLogs($debug, $file, $msg);
    $link = $url . '/viewinvoice.php?id=' . $invoiceId . '&paymentsuccess=true';
    header('Location:' . $link, true);

} else {

    $_POST['x_error'] = $message = 'Payment return: Invoice is not Paid';
    $note = 'AmwalPay : Payment is not completed';
    $msg = 'In callback action, for order #'.$invoiceId.' '.$note;
    amwalpay::addLogs($debug, $file, $msg);
    $link = $url . '/viewinvoice.php?id=' . $invoiceId . '&paymentfailed=true';
    header('Location:' . $link, true);

}
logTransaction($params['name'], $_POST, $transactionStatus);